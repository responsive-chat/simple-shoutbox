<center><font color="#bbbbbb"><small>Copyright &copy; 2019. All rights reserved.</small></font><br><br>
 <a href='http://u-on.eu/in.php?u=95009'><img src='http://u-on.eu/c.php?u=95009' alt='U-ON'></a><br><br>

<!-- BOOM.GE COUNTER CODE START -->
<script type=text/javascript src="http://links.boom.ge/jc.php?id=61707"></script>
<noscript><a href="http://top.boom.ge/index.php?id=61707" target="_blank" > <img src="http://links.boom.ge/nojs.php?id=61707" border="0" alt="BOOM.GE"></a></noscript>
<!-- BOOM.GE COUNTER CODE END -->

</center>

<br><br></p>