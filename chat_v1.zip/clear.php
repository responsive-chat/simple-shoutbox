<?php
$fh = fopen( 'chat.txt', 'w' );
fclose($fh);
?>
<html>
<head>
<meta http-equiv="refresh" content="1;url=http://mychat.eu.org" />
<title>Clear Log</title>
</head>
<body>
<center>
Log data successfully deleted
</center>
</body>
</html>