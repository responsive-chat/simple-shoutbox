function chBackcolor(color) {
   document.body.style.background = color;
}