<center>
<br><br><font color="#888888">
Created by Merabi Mazmaniani<br>
Sponsored by <a href='http://freewha.com'>freewha.com</a><br>
Copyright &copy; 2019 <a href='http://mychat.eu.org'>mychat.eu.org</a> All rights reserved.</font>
<br><br>
 <a href='http://u-on.eu/in.php?u=95009'><img src='http://u-on.eu/c.php?u=95009' alt='U-ON'></a><br><br>
<!-- BOOM.GE COUNTER CODE START -->
<script type=text/javascript src="http://links.boom.ge/jc.php?id=61707"></script>
<noscript><a href="http://top.boom.ge/index.php?id=61707" target="_blank" > <img src="http://links.boom.ge/nojs.php?id=61707" border="0" alt="BOOM.GE"></a></noscript>
<!-- BOOM.GE COUNTER CODE END -->
<br><br></center>