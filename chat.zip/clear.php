<?php
$fh = fopen( 'messages.json', 'w' );
fclose($fh);
?>